#Iris.xml was not available. Hence the same solution is illustrated with a different .xml file


require('XML')
library("methods")

df <- xmlToDataFrame("data.xml")
print(df)
